<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/principale.css">
    <link rel="stylesheet" href="css/styleform.css">
    <title>Insérer</title>
</head>

<body>
<?php include "PHP/INC/verifwrite_inc.php";?>
    
    <?php
    $datafilm = $_POST['datafilm'];
    $datareal1 = $_POST['nomreal1'] . "," . $_POST['prenomreal1'] . "," . $_POST['datereal1'];
    ?>

    <section id="Connexion">
        <form action="insertacteur.php" method="POST" enctype="multipart/form-data">

            <h1>Ajouts Producteurs</h1>
            <label for="nomprod">Nom du 1er Producteur : <span style="color: red">*</span></label><br />
            <input type="text" name="nomprod" id="nomprod" placeholder="Entrer le nom du 1er Producteur" minlength="2" maxlength="60" size="25" required /><br />

            <label for="prenomprod">Prénom du 1er Producteur : <span style="color: red">*</span></label><br />
            <input type="text" name="prenomprod" id="prenomprod" placeholder="Entrer le nom du 1er Producteur" minlength="2" maxlength="60" size="25" required /><br />


            <label for="nomprod2">Nom du 2ème Producteur : </span></label><br />
            <input type="text" name="nomprod2" id="nomprod2" placeholder="Entrer le nom du 2ème Producteur" minlength="2" maxlength="60" size="25" /><br />

            <label for="prenomprod2">Prénom du 2ème Producteur:</label><br />
            <input type="text" name="prenomprod2" id="prenomprod2" placeholder="Entrer le nom du 2ème Producteur" minlength="2" maxlength="60" size="25" /><br />

            <label for="nomstudio">Nom du studio de production : <span style="color: red">*</span></label><br />
            <input type="text" name="nomstudio" id="nomstudio" placeholder="Entrer le nom du studio" minlength="2" maxlength="60" size="25" required /><br />



            <input type="hidden" name="datafilm" value="<?php echo ($datafilm); ?>">
            <input type="hidden" name="datareal1" value="<?php echo ($datareal1); ?>">
            <?php
            if (isset($_POST['nomreal2']) && $_POST['prenomreal2'] && isset($_POST['datereal2'])) {
                $datareal2 = $_POST['nomreal2'] . "," . $_POST['prenomreal2'] . "," . $_POST['datereal2'];
            ?>
                <input type="hidden" name="datareal2" value="<?php echo ($datareal2); ?>">
            <?php
            }
            ?>
            <input type="submit" value="Suivant" />
            <h4>Tous les champs avec <span style="color: red">*</span> sont obligatoires</h4>
        </form>
    </section>
</body>

</html>