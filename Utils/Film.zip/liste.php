<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/principale.css">
	<link rel="stylesheet" href="css/styletab.css">
	<title>Liste Information</title>
</head>

<body>
	<?php
	include "PHP/INC/verifread_inc.php";
	?>

	<?php
	require "PHP/INC/connexiondb_inc.php";
	require "PHP/INC/securite_inc.php";

	$db = connexion();
	clesession();

	$choix = $_POST['choix'];
	if ($choix == 'Liste Film') { ?>
		<table>
			<tr>
				<td>Titre</td>
				<td>Nom Réalisateur</td>
				<td>Année de sortie</td>
			</tr>
			<?php
			if (!empty($_POST['Genre'])  && empty($_POST['date1']) && empty($_POST['date2'])) {
				$Genre = $_POST['Genre'];

				$query = $db->prepare("SELECT Films.IdFilms,Films.Titre,Films.Year,Realisateur.Nom
				FROM Films INNER JOIN Avoir ON Films.IdFilms = Avoir.IdFilms
				INNER JOIN Genre ON Genre.IdGenre = Avoir.IdGenre 
				INNER JOIN Realise ON Films.IdFilms = Realise.IdFilms
				INNER JOIN Realisateur ON Realisateur.IdReal = Realise.IdReal
				WHERE Genre.Genre = :Genre 
				ORDER BY Realisateur.Nom DESC LIMIT 25");
				$query->bindValue(":Genre", $Genre);
			} elseif (!empty($_POST['Genre']) && !empty($_POST['date1']) && !empty($_POST['date2'])) {

				$date1 = $_POST['date1'];
				$date2 = $_POST['date2'];

				$query = $db->prepare("SELECT Films.IdFilms,Films.Titre,Films.Year,Realisateur.Nom
				FROM Films INNER JOIN Avoir ON Films.IdFilms = Avoir.IdFilms
				INNER JOIN Genre ON Genre.IdGenre = Avoir.IdGenre 
				INNER JOIN Realise ON Films.IdFilms = Realise.IdFilms
				INNER JOIN Realisateur ON Realisateur.IdReal = Realise.IdReal
				WHERE Year >= :date1 AND Year <= :date2 AND Genre.Genre = :Genre 
				ORDER BY Realisateur.Nom DESC LIMIT 25");
				$query->bindValue(":date1", $date1);
				$query->bindValue(":date2", $date2);
				$query->bindValue(":Genre", $Genre);
			} else if (empty($_POST['Genre']) && !empty($_POST['date1']) && !empty($_POST['date2'])) {
				$date1 = $_POST['date1'];
				$date2 = $_POST['date2'];

				$query = $db->prepare("SELECT Films.IdFilms,Films.Titre,Films.Year,Realisateur.Nom
				FROM Films INNER JOIN Avoir ON Films.IdFilms = Avoir.IdFilms
				INNER JOIN Genre ON Genre.IdGenre = Avoir.IdGenre 
				INNER JOIN Realise ON Films.IdFilms = Realise.IdFilms
				INNER JOIN Realisateur ON Realisateur.IdReal = Realise.IdReal 
				WHERE Year >= :date1 AND Year <= :date2 
				ORDER BY Realisateur.Nom DESC LIMIT 25");
				$query->bindValue(":date1", $date1);
				$query->bindValue(":date2", $date2);
			} else {
				header("location: info.php?choix=listGenreDate");
			}
			$query->execute();
			while ($result = $query->fetch(PDO::FETCH_BOTH)) { ?>
				<tr>
					<td>
						<?php echo ('<a href="fichecomp.php?id=' . $result[0] . '&&choix=Film "> ' . $result[1] . ' </a>'); ?>
					</td>
					<td><?php echo $result[3] ?></td>
					<td><?php echo $result[2] ?></td>
				</tr>

			<?php	} ?>
		</table> <?php
				} else if ($choix == 'Liste Acteur Film' || $choix == 'Liste Producteur Film') {
					if ($choix == 'Liste Acteur Film') {
						$nom = $_POST['nom'];
						$nom2 = $_POST['nom2'];

						if (!empty($_POST['prenom2'])) {
							$prenom2 = $_POST['prenom2'];

							if (!empty($_POST['prenom'])) {
								$prenom = $_POST['prenom'];

								$query = $db->prepare("SELECT Acteur.IdActeur,Acteur.Nom,Acteur.Prenom FROM Acteur 
                WHERE (Acteur.Nom LIKE :nom AND Acteur.Prenom LIKE :prenom) OR (Acteur.Nom LIKE :nom2 AND Acteur.Prenom LIKE :prenom2)
								GROUP BY Acteur.IdActeur,Acteur.Nom,Acteur.Prenom FROM Acteur");
								$query->bindValue(":nom", "%$nom");
								$query->bindValue(":prenom", "%$prenom");
								$query->bindValue(":nom2", "%$nom2");
								$query->bindValue(":prenom2", "%$prenom2");
								$query->execute();
							} else {
								$query = $db->prepare("SELECT Acteur.IdActeur,Acteur.Nom,Acteur.Prenom FROM Acteur 
                WHERE Acteur.Nom LIKE :nom OR (Acteur.Nom LIKE :nom2 AND Acteur.Prenom LIKE :prenom)
								GROUP BY Acteur.IdActeur,Acteur.Nom,Acteur.Prenom FROM Acteur");
								$query->bindValue(":nom", "%$nom");
								$query->bindValue(":nom2", "%$nom2");
								$query->bindValue(":prenom2", "%$prenom2");
								$query->execute();
							}
						} else if (empty($_POST['prenom2'])) {
							$nom2 = $_POST['nom2'];

							if (!empty($_POST['prenom'])) {
								$prenom = $_POST['prenom'];

								$query = $db->prepare("SELECT Acteur.IdActeur,Acteur.Nom,Acteur.Prenom FROM Acteur
              	WHERE (Acteur.Nom LIKE :nom AND Acteur.Prenom LIKE :prenom) OR Acteur.Nom LIKE :nom2
								GROUP BY Acteur.IdActeur,Acteur.Nom,Acteur.Prenom");
								$query->bindValue(":nom", "%$nom");
								$query->bindValue(":prenom", "%$prenom");
								$query->bindValue(":nom2", "%$nom2");
								$query->execute();
							} else {
								$query = $db->prepare("SELECT Acteur.IdActeur,Acteur.Nom,Acteur.Prenom FROM Acteur
                WHERE Acteur.Nom LIKE :nom OR Acteur.Nom LIKE :nom2
								GROUP BY  Acteur.IdActeur,Acteur.Nom,Acteur.Prenom");
								$query->bindValue(":nom", "%$nom");
								$query->bindValue(":nom2", "%$nom2");
								$query->execute();
							}
						} 
					?>
			<table>
				<tr>
					<td>Nom</td>
					<td>Prénom</td>
					<td></td>
				</tr>
				<?php
						while ($result = $query->fetch(PDO::FETCH_BOTH)) { ?>
					<tr>
						<td><?php echo $result[1]; ?></td>
						<td><?php echo $result[2]; ?></td>
						<td><?php echo ('<a href="fichecomp.php?id=' . $result[0] . '&&choix=Acteur"> Voir tous ses films</a>'); ?></td>
					</tr>

				<?php	} ?>
			</table><?php
					} else if ($choix == 'Liste Producteur Film') {
						if (!empty($_POST['nom']) && empty($_POST['prenom'])) {
							$nom = $_POST['nom'];
							if (!empty($_POST['nomstudio'])) {
								$nomstudio = $_POST['nomstudio'];

								$query = $db->prepare("SELECT Producteur.IdProducteur,Producteur.Nom,Producteur.Prenom,Films.Titre,Films.Year,Producteur.NomStudio FROM Produit 
                WHERE Producteur.Nom LIKE :nom AND Producteur.NomStudio LIKE :nomstudio
								GROUP BY Producteur.IdProducteur,Producteur.Nom,Producteur.Prenom,Films.Titre,Films.Year,Producteur.NomStudio");
								$query->bindValue(":nom", "$nom%");
								$query->bindValue(":nomstudio", "$nomstudio%");
								$query->execute();
							} else {
								$query = $db->prepare("SELECT Producteur.IdProducteur,Producteur.Nom,Producteur.Prenom,Films.Titre,Films.Year,Producteur.NomStudio FROM Produit 
                WHERE Producteur.Nom LIKE :nom
								GROUP BY Producteur.IdProducteur,Producteur.Nom,Producteur.Prenom,Films.Titre,Films.Year,Producteur.NomStudio");
								$query->bindValue(":nom", "$nom%");
								$query->execute();
							}
						} else if (!empty($_POST['nom']) && !empty($_POST['prenom'])) {
							$nom = $_POST['nom'];
							$prenom = $_POST['prenom'];
							if (!empty($_POST['nomstudio'])) {
								$nomstudio = $_POST['nomstudio'];

								$query = $db->prepare("SELECT Producteur.IdProducteur,Producteur.Nom,Producteur.Prenom,Films.Titre,Films.Year,Producteur.NomStudio FROM Produit  
                				WHERE Producteur.Nom LIKE :nom AND Producteur.Prenom LIKE :prenom AND Producteur.NomStudio LIKE :nomstudio
								GROUP BY Producteur.IdProducteur,Producteur.Nom,Producteur.Prenom,Films.Titre,Films.Year,Producteur.NomStudio");
								$query->bindValue(":nom", "$nom%");
								$query->bindValue(":prenom", "$prenom%");
								$query->bindValue(":nomstudio", "$nomstudio%");
								$query->execute();
							} else {
								$query = $db->prepare("SELECT Producteur.IdProducteur,Producteur.Nom,Producteur.Prenom,Films.Titre,Films.Year,Producteur.NomStudio FROM Produit  
                WHERE Producteur.Nom LIKE :nom AND Producteur.Prenom LIKE :prenom
                GROUP BY Films.IdFilms,Producteur.Nom,Producteur.Prenom,Films.Titre,Films.Year,Producteur.NomStudio 
								ORDER BY Producteur.Nom DESC LIMIT 25");
								$query->bindValue(":nom", "$nom%");
								$query->bindValue(":prenom", "$prenom%");
								$query->execute();
							}
						} else if (!empty($_POST['nomstudio'])) {
							$nomstudio = $_POST['nomstudio'];

							$query = $db->prepare("SELECT Producteur.IdProducteur,Producteur.Nom,Producteur.Prenom,Films.Titre,Films.Year,Producteur.NomStudio FROM Produit  
              WHERE Producteur.NomStudio LIKE :nomstudio
              GROUP BY Producteur.IdProducteur,Producteur.Nom,Producteur.Prenom,Films.Titre,Films.Year,Producteur.NomStudio");
							$query->bindValue(":nomstudio", "$nomstudio%");
							$query->execute();
						} else {
							header("location: info.php?choix=listProd");
						}
					?>
			<table>
				<tr>
					<td>Nom</td>
					<td>Prénom</td>
					<td>Titre Film</td>
					<td>Année de Sortie</td>
					<td>Nom du studio</td>
				</tr>
				<?php
						while ($result = $query->fetch(PDO::FETCH_BOTH)) { ?>
					<tr>
						<td><?php echo $result[1]; ?></td>
						<td><?php echo $result[2]; ?></td>
						<td><?php echo ('<a href="fichecomp.php?id=' . $result[0] . '&&choix=Producteur"> ' . $result[3] . '</a>'); ?></td>
						<td><?php echo $result[4]; ?></td>
						<td><?php echo $result[5]; ?></td>
					</tr>
				<?php	} ?>
			</table>
			<?php
					} 
				}
				else {
					header("location:index.php");
				}
			?>



</body>

</html>