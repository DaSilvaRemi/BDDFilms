<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/principale.css">
    <link rel="stylesheet" href="css/styleform.css">
    <title>Insérer</title>
</head>

<body>
<?php 
include "PHP/INC/verifwrite_inc.php"; ?>

    <section id="Connexion">
        <form action="insertreal.php" method="POST" enctype="multipart/form-data">
            <h1>Ajouts Film</h1>
            <label for="titre">Titre Original : <span style="color: red">*</span></label><br />
            <input type="text" name="titre" id="titre" placeholder="Entrer le Titre original du film" minlength="2" maxlength="70" size="20" required /><br /><br />

            <label for="titre">Titre Fr : </label><br />
            <input type="text" name="titreFr" id="titreFr" placeholder="Entrer le Titre en français" minlength="2" maxlength="70" size="20" /><br /><br />
            
            <label for="Genre">Genre du film : <span style="color: red">*</span></label>
            <select name="Genre" id="Genre" required>
						<?php
						require "PHP/INC/connexiondb_inc.php";
						$db = connexion();
						$requete = "SELECT Genre FROM Genre";
						$reponse = $db->query($requete);
						while ($data = $reponse->fetch(PDO::FETCH_BOTH)) { ?>

							<option value="<?php $data[0]; ?>"><?php echo ($data[0]); ?></option>
						<?php	}
						$reponse->closeCursor(); //Fermetrure de l'envoie des requêtes
						deconnexion($db); // fermer la connexion
						?>
					</select>
            <label for="date">Année de sortie : <span style="color: red">*</span></label>
            <input type="number" name="date" id="date" placeholder="Entrer l'année de sortie du film" min="1900" max="2100" size="4" required>

            <label for="synopsis">Scénariste : <span style="color: red">*</span></label><br />
            <input type="text" name="synopsis" id="synopsis" placeholder="Entrer les scénaristes" minlength="10" maxlength="2000" size="250" required /><br /><br />

            <label for="note">Remarque : <span style="color: red">*</span></label>
            <input type="text" name="note" id="note" placeholder="Entrer la remarque du film" minlength="2" maxlength="2000" size="250" required /><br /><br />

			<label for="duree">Durée du Film en minutes : <span style="color: red">*</span></label>
			<input type="number" name="duree" id="duree" placeholder="Entrer la durée du film en min" min="30" max="240" size="3" required>
			
            <label for="support">Support : <span style="color: red">*</span></label>
            <select name="support" id="support" required>
			<option value="">Choisir un support</option>
						<?php
						require "PHP/INC/connexiondb_inc.php";
						$db = connexion();
						$requete = "SELECT Support.TypeSupport FROM Support";
						$reponse = $db->query($requete);
						while ($data = $reponse->fetch(PDO::FETCH_BOTH)) { ?>

							<option value="<?php $data[0]; ?>"><?php echo ($data[0]); ?></option>
						<?php	}
						$reponse->closeCursor(); //Fermetrure de l'envoie des requêtes
						deconnexion($db); // fermer la connexion
						?>
					</select>

            <input type="submit" value="Suivant" />
            <h4>Tous les champs avec <span style="color: red">*</span> sont obligatoires</h4>
        </form>
    </section>
</body>

</html>