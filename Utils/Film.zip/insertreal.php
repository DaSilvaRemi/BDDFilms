<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/principale.css">
    <link rel="stylesheet" href="css/styleform.css">
    <title>Insérer</title>
</head>

<body>
    <?php include "PHP/INC/verifwrite_inc.php";?>

    <?php
    if (empty($_POST['titreFr'])) { //On vérifie si la personne à donnée un titre en fr
        $titreFr = "";
    } else {
        $titreFr = $_POST['titreFr'];
    }
    $datafilm = $_POST['titre'] . "," . $titreFr . $_POST['Genre'] . "," . $_POST['synopsis'] . "," .
        $_POST['note'] .",".$_POST['duree'] . "," . $_POST['date'] . "," . $_POST['support'];
    ?>

    <section id="Connexion">
        <form action="insertprod.php" method="POST" enctype="multipart/form-data">

            <h1>Ajouts Réalisateurs</h1>
            <label for="nomreal1">Nom du 1er Réalisateur : <span style="color: red">*</span></label><br />
            <input type="text" name="nomreal1" id="nomreal1" placeholder="Entrer le nom du 1er réalisateur" minlength="2" maxlength="60" size="25" required /><br />

            <label for="prenomreal1">Prénom du 1er Réalisateur : <span style="color: red">*</span></label><br />
            <input type="text" name="prenomreal1" id="prenomreal1" placeholder="Entrer le prénom du 1er réalisateur" minlength="2" maxlength="60" size="25" required /><br />

            <label for="datereal1">Date naissance du 1er Réalisateur : <span style="color: red">*</span></label><br />
            <input type="date" name="datereal1" id="datereal1" required>

            <label for="nomreal2">Nom du 2ème Réalisateur : </label><br />
            <input type="text" name="nomreal2" id="nomreal2" placeholder="Entrer le nom du 2ème réalisateur" minlength="2" maxlength="60" size="25" /><br />

            <label for="prenomreal2">Prénom du 2ème Réalisateur : </label><br />
            <input type="text" name="prenomreal2" id="prenomreal2" placeholder="Entrer le prénom du 2ème réalisateur" minlength="2" maxlength="60" size="25" /><br />

            <label for="datereal2">Date naissance du 2ème Réalisateur : </label><br />
            <input type="date" name="datereal2" id="datereal2">
            <br>

            <input type="hidden" name="datafilm" value="<?php echo ($datafilm); ?>">
            <input type="submit" value="Suivant" />
            <h4>Tous les champs avec <span style="color: red">*</span> sont obligatoires</h4>
        </form>
    </section>
</body>

</html>