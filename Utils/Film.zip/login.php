<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/principale.css">
  <link rel="stylesheet" href="css/styleform.css">
  <title>Accès</title>
</head>

<body>
  <?php
  require "PHP/INC/verifread_inc.php";
  ?>

  <section id="Connexion">
    <form action="PHP/Script/connexion.php" method="post">
      <h1>Connexion</h1>
      <label for="user">Identifiant: </label><br />
      <input type="text" name="user" id="user" placeholder="Entrer vôtre identifiant" size="30" minlength="3" maxlength="15" required /><br /><br />
      <label for="mdp">Mot de passe: </label><br />
      <input type="password" name="mdp" id="mdp" placeholder="Entrer vôtre mot de passe" size="30" minlength="3" maxlength="15" required /><br /><br />
      <input type="submit" value="Envoyer" />


      <?php
      if (isset($_GET['erreur'])) {
        $err = $_GET['erreur'];
        if ($err == 1 || $err == 2) {
          echo "<p style='color:white;background-color: red;border : 2px,solid,red'>Utilisateur ou mot de passe incorrect</p>";
        } 
        else {
          echo "<p style='color:white;background-color: red;border : 2px,solid,red'>Vous n'avez pas les droits nécessaire pour accéder à cette page.
            Veuillez vous reconnectez</p>";
        }
      }
      ?>
    </form>
  </section>
</body>

</html>